export const colorElectricPink = "#F5167E";

export const colorCetaceanBlue = "#0A075F";

export const colorPalatinateBlue = "#3D37F1";

export const colorIndigo = "#242565";

export const colorPurpleNavy = "#4C4D8B";

export const colorDimGray = "#6A6A6A";

export const colorWhite = "#FFFFFF";

export const colorAliceBlue = "#F2F4FF";

export const colorAntiFlashWhite = "#F3F3F3";

export const colorBlack = "#000000";

export const colorLavender = "#EEE1FF";

export const colorCharlestonGreen = "#272727";
