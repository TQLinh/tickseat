
export const DATA_EVENT_TYPE = [
    "Live Music",
    "E-Sports",
    "Sport",
    "Workshops",
    "Art",
];