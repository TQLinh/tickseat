import React from 'react'

function HomePageAdmin() {
  return (
    <>
        <h1>HomePageAdmin</h1>
    </>
  )
}

export default HomePageAdmin