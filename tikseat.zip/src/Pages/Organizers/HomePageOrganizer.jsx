import React from 'react'

function HomePageOrganizer() {
  return (
    <>
        <h1>HomePageOrganizer</h1>
    </>
  )
}

export default HomePageOrganizer