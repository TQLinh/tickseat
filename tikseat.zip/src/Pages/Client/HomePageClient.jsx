import React from 'react'

function HomePageClient() {
  return (
    <>
        <h1>HomePageClient</h1>
    </>
  )
}

export default HomePageClient